package com.nourislam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF176B4D)
private val PaleGreen = Color(0xFFEAF5EF)
private val Ink = Color(0xFF1D2B24)
private val Muted = Color(0xFF65756C)
private val Surface = Color(0xFFF7FAF8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NourIslamApp() }
    }
}

@Composable
fun NourIslamApp() {
    var selected by remember { mutableIntStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            secondary = PaleGreen,
            background = Surface,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Surface,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected == 0, { selected = 0 }, icon = { Icon(Icons.Default.AccessTime, null) }, label = { Text("Prières") })
                    NavigationBarItem(selected == 1, { selected = 1 }, icon = { Icon(Icons.Default.MenuBook, null) }, label = { Text("Coran") })
                    NavigationBarItem(selected == 2, { selected = 2 }, icon = { Icon(Icons.Default.Explore, null) }, label = { Text("Qibla") })
                    NavigationBarItem(selected == 3, { selected = 3 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Réglages") })
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (selected) {
                    0 -> PrayerScreen()
                    1 -> QuranScreen()
                    2 -> QiblaScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(top = 20.dp, start = 20.dp, end = 20.dp, bottom = 16.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Green)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Muted, fontSize = 14.sp)
    }
}

@Composable
fun PrayerScreen() {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Header("Nour Islam", "Ta foi, chaque jour.")
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Green),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("ASSALAMOU ALAYKOUM", color = Color(0xFFD6EBDD), fontSize = 12.sp, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Prends un moment pour toi.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Les horaires réels seront affichés après configuration de ta ville.", color = Color(0xFFE2F0E8), fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(6.dp))
                        Text("Ville non configurée", color = Color.White, fontWeight = FontWeight.Medium)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Les cinq prières", modifier = Modifier.padding(horizontal = 20.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
        }
        items(listOf("Fajr" to "--:--", "Dohr" to "--:--", "Asr" to "--:--", "Maghrib" to "--:--", "Isha" to "--:--")) { prayer ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(PaleGreen, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.WbTwilight, null, tint = Green)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(prayer.first, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Text(prayer.second, color = Muted, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item {
            Text("Choisis ta ville dans Réglages pour préparer le calcul des horaires.", color = Muted, fontSize = 12.sp,
                modifier = Modifier.padding(20.dp))
        }
    }
}

@Composable
fun QuranScreen() {
    var query by remember { mutableStateOf("") }
    val surahs = listOf(
        "1" to ("Al-Fatiha" to "L’Ouverture"),
        "2" to ("Al-Baqara" to "La Vache"),
        "18" to ("Al-Kahf" to "La Caverne"),
        "36" to ("Ya-Sin" to "Ya-Sin"),
        "55" to ("Ar-Rahman" to "Le Tout Miséricordieux"),
        "67" to ("Al-Mulk" to "La Royauté"),
        "112" to ("Al-Ikhlas" to "Le Monothéisme pur"),
        "113" to ("Al-Falaq" to "L’Aube naissante"),
        "114" to ("An-Nas" to "Les Hommes")
    )
    Column(Modifier.fillMaxSize()) {
        Header("Le Saint Coran", "Retrouve facilement une sourate.")
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Rechercher une sourate") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text("SOURATES", modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        LazyColumn {
            items(surahs.filter { it.second.first.contains(query, true) || it.second.second.contains(query, true) || it.first == query }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).background(PaleGreen, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Text(item.first, color = Green, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.second.first, fontWeight = FontWeight.SemiBold)
                            Text(item.second.second, color = Muted, fontSize = 13.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Green)
                    }
                }
            }
        }
        Text("Version de démarrage : le texte arabe, la traduction et l’audio doivent être reliés à une source vérifiée.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
    }
}

@Composable
fun QiblaScreen() {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Header("Direction Qibla", "Oriente-toi vers la Kaaba.")
        Spacer(Modifier.height(20.dp))
        Box(
            Modifier.size(230.dp).background(Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(190.dp).background(PaleGreen, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Explore, contentDescription = "Boussole Qibla à connecter", tint = Green, modifier = Modifier.size(100.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Boussole à calibrer", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(
            "La direction exacte nécessite la localisation et les capteurs du téléphone. Ils seront activés dans la prochaine étape.",
            textAlign = TextAlign.Center, color = Muted, fontSize = 14.sp
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Explore, null)
            Spacer(Modifier.width(8.dp))
            Text("Préparer la boussole")
        }
    }
}

@Composable
fun SettingsScreen() {
    var city by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Calcul à définir") }
    Column(Modifier.fillMaxSize()) {
        Header("Réglages", "Personnalise Nour Islam.")
        Card(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Ville", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = city, onValueChange = { city = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ex. : Chambéry") },
                    singleLine = true
                )
                Spacer(Modifier.height(16.dp))
                Text("Méthode de calcul des prières", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(method, color = Muted)
                Text("À configurer selon la méthode souhaitée et les horaires de ta mosquée locale.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Text("Langue : Français", color = Ink)
                Spacer(Modifier.height(8.dp))
                Text("Thème : Blanc & vert", color = Ink)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Cette version est un socle de développement. Les calculs d’horaires, notifications, texte complet du Coran, audio et boussole réelle restent à intégrer.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp))
    }
}
