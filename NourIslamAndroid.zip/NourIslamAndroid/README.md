# Nour Islam — prototype Android

Application de démarrage Android en Kotlin + Jetpack Compose, thème blanc et vert.

## Écrans inclus
- Prières : liste des cinq prières, état initial sans horaires fictifs.
- Coran : recherche dans une petite liste de sourates.
- Qibla : écran de préparation de la boussole.
- Réglages : champ pour la ville et indication de configuration.

## Ouvrir le projet
1. Installer Android Studio (version récente).
2. Ouvrir le dossier `NourIslamAndroid`.
3. Laisser Gradle synchroniser le projet.
4. Lancer sur un émulateur ou un appareil Android.

## Important
Ceci est un prototype de départ, pas encore une application religieuse complète prête à publier. Les horaires réels nécessitent un moteur de calcul fiable et une méthode choisie; la Qibla nécessite les capteurs et la localisation; les textes du Coran/traductions/audio doivent venir de sources vérifiées. Les notifications et les permissions Android ne sont pas encore implémentées.
